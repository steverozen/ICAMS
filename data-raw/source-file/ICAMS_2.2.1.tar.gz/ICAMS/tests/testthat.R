library(testthat)
library(ICAMS)

test_check("ICAMS")
